import React from 'react'

function Prop(props) {
  return (
    <>
     <div>{props.title}</div>
    </>
  )
}

export default Prop