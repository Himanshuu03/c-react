import React from 'react'
import './header.css';
function Header(props) {
  return (
    <div className=''>
        <ul>
            <li><a href='.'>Home</a></li>
            <li><a href='.'>Aboutus</a></li>
            <li><a href='.'>Services</a></li>
            <li><a href='.'>FAQ</a></li>
            <li><a href='.'>Contactus</a></li>
        </ul>
    </div>
  )
}

export default Header