import './App.css';
import Header from './components/Header';
import logo from './logo.svg'
import Componet from './components/Componet';
import { useState } from 'react';
import Prop from './components/Prop';
const user = {
  firstName :"Himanshu",
  lastName :"Jangra"
}
function fullName(obj){
  return(
    `Full Name :-> ${obj.firstName} ${obj.lastName}`
  )
}

function App() {
  const [title,setTitle] = useState("My Name");
  function changeHandler(){
    if(title === "Himanshu"){
      setTitle("My Name");
    }
    else{
      setTitle("Himanshu");
    }
  }
  return (
    <div>
      <div className="container">
        <div className='header'>
          <div className='logo'>
            <img src={logo} className='logoimg' alt='logo'/>
          </div>
          <div>
            <Header></Header>
          </div>
        </div>
        <div className='content'>
          <Componet />
        </div>
      <div className='name'>
        {
          fullName(user)
        }
      </div>
      <Prop title = {title}/>
      <button onClick={changeHandler}>Change</button>
      </div>
    </div>
  );
}

// function AboutUs() {
//   return (
//     <div className="aboutUs"> 
//        <p>Hello this is aboutus Page</p>
//     </div>
//   )
// }
export default App;
